
public class Main {
	public static void main(String[] args) {
		AnimalShelter as = new AnimalShelter();
		
		as.enter(new Dog("Brad"));  as.enter(new Dog("Tom")); 
		as.enter(new Cat("Cindy")); as.enter(new Dog("Jake")); 
		as.enter(new Cat("Jenny")); as.enter(new Dog("Alex"));
		as.enter(new Cat("Lucy"));  as.enter(new Cat("Maggie"));
		as.print();
		as.adoptAny();
		as.print();
		as.adoptCat();
		as.print();
		as.adoptDog();
		as.print();
		as.adoptAny();
		as.print();
		as.adoptDog();
		as.print();

	}
}
