
public class Dog extends Animal {
	private String name;
	
	public Dog(String name) {
		super(name);
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
}
