
public class AnimalShelter {
	Animal ani = new Animal();

	public void enter(Cat cat) {
		ani.add(cat);
	}

	public void enter(Dog dog) {
		ani.add(dog);
	}

	public void adoptAny() {
		ani.remove();
	}

	public void adoptCat() {
		adoptAnimal("Cat");
	}

	public void adoptDog() {
		adoptAnimal("Dog");
	}

	public <E> void adoptAnimal(String type) {
		int fixedSize = ani.size(); // ���� ����� �޾Ƽ� �������� �ʰ� ������ ����
		Animal arrAni[] = new Animal[fixedSize + 1];
		int cnt = 0;

		if (type == "Cat") {
			for (int i = 1; i <= fixedSize; i++) {
				Animal item = (Animal) ani.remove();
				if (item instanceof Cat && cnt == 0) {
					cnt += 1;
					continue;
				}
				if (cnt == 0) {
					arrAni[i] = item;
				} else {
					arrAni[i - 1] = item;
				}
			}
		} else if (type == "Dog") {
			for (int i = 1; i <= fixedSize; i++) {
				Animal item = (Animal) ani.remove();
				if (item instanceof Dog && cnt == 0) {
					cnt += 1;
					continue;
				}
				if (cnt == 0) {
					arrAni[i] = item;
				} else {
					arrAni[i - 1] = item;
				}
			}
		}
		for (int i = 1; i < arrAni.length; i++) {
			ani.add(arrAni[i]); // ����� ���� ���� ������ �迭�� �ٽ� ť�� ����
		}
	}

	public void print() {
		ani.print();
	}
}